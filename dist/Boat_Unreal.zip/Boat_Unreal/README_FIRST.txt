KAI'S BOAT for Unreal Engine 5

Open IMPORT_GUIDE.html (or IMPORT_GUIDE.md) and follow Steps 1 to 6. Import Kai first (Kai_Unreal.zip).

Quick start:
  1. Import Content/Meshes/*.fbx as Static Meshes: Auto Generate Collision off, One Convex Hull Per UCX on,
     import normals, scale 1. The collision and sockets are in the files.
  2. Import Content/Animations/*.fbx onto SK_Kai_Skeleton (animations only) and make the blend space
     BS_Kai_Boat_Steer (Steer -1 .. 1).
  3. Kai's Anim Blueprint: IsDriving and BoatSteer, Blend Poses by bool.
  4. Enhanced Input: IA_Boat_Throttle, IA_Boat_Steer, IA_Boat_Exit in IMC_Boat; IA_Interact on Kai.
  5. BP_KaiBoat (Pawn): hull simulates physics (150 kg), buoyancy at the Pontoon_* sockets, thrust at the
     propeller, water drag; Kai attaches to Seat_Driver and the controller possesses the boat.

Folders: Content (import these), Reference (sockets, physics tuning, check reports), Previews (renders),
Source_Blender (Boat.blend, and Kai_Boat.blend with Kai seated at the wheel).
