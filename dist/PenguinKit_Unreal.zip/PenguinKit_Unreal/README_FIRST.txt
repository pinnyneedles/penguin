PENGUIN LEVEL KIT for Unreal Engine 5

Open IMPORT_GUIDE.html (or IMPORT_GUIDE.md) and follow Steps 1 to 6.

Quick start:
  1. Import Content/Textures. Normal_DX = Normalmap, ORM = Masks (no sRGB).
  2. Build M_PenguinKit_Master and instances MI_Ice, MI_Snow, MI_Rock (guide, Step 3).
  3. Import all of Content/Meshes as static meshes, scale 1, with UCX collision and sockets on,
     auto-generated collision off.
  4. Replace References: M_Ice -> MI_Ice, M_Snow -> MI_Snow, M_Rock -> MI_Rock.
  5. Snap pieces on a 100 cm grid. Chain slide-chute pieces through SOCKET_End.

22 meshes, centimetres, Z up. Folders: Content (import these), Reference (sizes,
triangles, pivots, sockets), Previews (renders), Source_Blender (editable scene).
